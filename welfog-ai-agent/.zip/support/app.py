import os
import re
import json
import click 
import difflib
from secrets import token_hex
import sqlite3  
from datetime import datetime, timedelta
import requests
from flask import Flask, request, jsonify, render_template_string, redirect, url_for, flash, abort
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask.cli import with_appcontext
from langdetect import detect
from deep_translator import GoogleTranslator
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity  
from dotenv import load_dotenv
load_dotenv()

# ================= INIT =================
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY") or token_hex(32)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KNOWLEDGE_DIR = os.path.join(BASE_DIR, "knowledge")

DB_NAME = "welfog_history.db"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(BASE_DIR, 'welfog_v2.db')
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["REMEMBER_COOKIE_HTTPONLY"] = True
app.config["REMEMBER_COOKIE_SAMESITE"] = "Lax"

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'admin_login'

# --- Admin Model ---
class AdminUser(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return AdminUser.query.get(int(user_id))

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS chats (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, title TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, sender TEXT, message TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)''')
    conn.commit()
    conn.close()

init_db()

@app.cli.command("create-admin")
@click.argument("username")
@click.argument("password")
@with_appcontext
def create_admin(username, password):
    db.create_all()
    username = (username or "").strip()
    if len(username) < 3:
        print("❌ Username must be at least 3 chars.")
        return
    if len(password or "") < 8:
        print("❌ Password must be at least 8 chars.")
        return
    existing = AdminUser.query.filter_by(username=username).first()
    if existing:
        print(f"❌ Admin '{username}' already exists.")
        return
    new_admin = AdminUser(username=username, password=generate_password_hash(password, method="pbkdf2:sha256"))
    db.session.add(new_admin)
    db.session.commit()
    print(f"✅ Admin '{username}' created successfully.")

LOGIN_UI = """
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Welfog Admin Login</title>
</head>
<body style="margin:0;min-height:100vh;background:radial-gradient(circle at top,#1e1e1e,#090909 55%);color:#eee;font-family:'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;padding:24px;">
  <form method="POST" style="width:min(420px,100%);background:#121212;border:1px solid #2a2a2a;border-radius:16px;padding:28px;box-shadow:0 20px 60px rgba(0,0,0,.45);">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
      <h2 style="margin:0;color:#ff7a00;">Welfog Admin</h2>
      <span style="font-size:12px;color:#8f8f8f;">Secure Login</span>
    </div>
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        {% for category, message in messages %}
          <div style="margin-bottom:12px;border-radius:10px;padding:10px 12px;font-size:13px;background:{% if category == 'error' %}#3d1414{% else %}#153c20{% endif %};color:{% if category == 'error' %}#ffb3b3{% else %}#aef5c0{% endif %};border:1px solid {% if category == 'error' %}#793131{% else %}#2a6f3d{% endif %};">
            {{ message }}
          </div>
        {% endfor %}
      {% endif %}
    {% endwith %}
    <label style="font-size:13px;color:#b9b9b9;">Username</label>
    <input type="text" name="username" placeholder="Enter username" style="width:100%;padding:12px;margin:8px 0 14px;border-radius:10px;border:1px solid #2f2f2f;background:#0e0e0e;color:#fff;outline:none;" required>
    <label style="font-size:13px;color:#b9b9b9;">Password</label>
    <input type="password" name="password" placeholder="Enter password" style="width:100%;padding:12px;margin:8px 0 20px;border-radius:10px;border:1px solid #2f2f2f;background:#0e0e0e;color:#fff;outline:none;" required>
    <button type="submit" style="width:100%;padding:12px;background:linear-gradient(135deg,#ff7a00,#ff9f4a);color:#fff;border:none;border-radius:10px;font-weight:700;cursor:pointer;">Login</button>
  </form>
</body>
</html>
"""

DASHBOARD_UI = """
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Welfog Admin Dashboard</title>
</head>
<body style="margin:0;background:#0b0b0b;color:#f5f5f5;font-family:'Segoe UI',sans-serif;">
  <header style="position:sticky;top:0;z-index:5;background:rgba(10,10,10,.92);backdrop-filter:blur(8px);border-bottom:1px solid #222;">
    <div style="max-width:1080px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;padding:14px 22px;">
      <div>
        <div style="font-size:20px;font-weight:800;color:#ff7a00;">Welfog Admin Panel</div>
        <div style="font-size:12px;color:#9a9a9a;">Knowledge base operations and content control</div>
      </div>
      <nav style="display:flex;gap:10px;align-items:center;">
        <a href="{{ url_for('admin_add_file') }}" style="text-decoration:none;color:#fff;background:#1f1f1f;border:1px solid #343434;padding:10px 14px;border-radius:10px;font-size:13px;">+ Add New File</a>
        <a href="{{ url_for('admin_logout') }}" style="text-decoration:none;color:#fff;background:#c93f3f;padding:10px 14px;border-radius:10px;font-size:13px;">Logout</a>
      </nav>
    </div>
  </header>

  <main style="max-width:1080px;margin:0 auto;padding:24px 22px 34px;">
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        {% for category, message in messages %}
          <div style="margin-bottom:12px;border-radius:10px;padding:12px 14px;font-size:13px;background:{% if category == 'error' %}#3d1414{% else %}#153c20{% endif %};color:{% if category == 'error' %}#ffb3b3{% else %}#aef5c0{% endif %};border:1px solid {% if category == 'error' %}#793131{% else %}#2a6f3d{% endif %};">
            {{ message }}
          </div>
        {% endfor %}
      {% endif %}
    {% endwith %}

    <section style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-bottom:16px;">
      <div style="padding:14px;border:1px solid #262626;background:#121212;border-radius:12px;">
        <div style="font-size:12px;color:#9a9a9a;">Total Knowledge Files</div>
        <div style="font-size:26px;font-weight:700;color:#ff9f4a;">{{ files|length }}</div>
      </div>
      <div style="padding:14px;border:1px solid #262626;background:#121212;border-radius:12px;">
        <div style="font-size:12px;color:#9a9a9a;">Current Admin</div>
        <div style="font-size:18px;font-weight:700;">{{ current_user.username }}</div>
      </div>
    </section>

    <section style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;">
      {% for file in files %}
      <article style="background:#121212;border:1px solid #242424;border-radius:14px;padding:14px;display:flex;justify-content:space-between;gap:10px;align-items:center;">
        <div>
          <div style="font-size:14px;color:#e7e7e7;font-weight:600;">📄 {{ file }}</div>
          <div style="font-size:12px;color:#888;">Knowledge file in support/knowledge</div>
        </div>
        <a href="{{ url_for('edit_kb_file', filename=file) }}" style="text-decoration:none;background:#1a1a1a;color:#ff9f4a;border:1px solid #ff7a00;padding:8px 12px;border-radius:9px;font-size:12px;font-weight:700;">Edit</a>
      </article>
      {% endfor %}
    </section>
  </main>
</body>
</html>
"""

EDIT_UI = """
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Edit {{ filename }}</title>
</head>
<body style="margin:0;background:#0b0b0b;color:#eee;font-family:'Segoe UI',sans-serif;">
  <header style="position:sticky;top:0;z-index:5;background:rgba(10,10,10,.92);backdrop-filter:blur(8px);border-bottom:1px solid #222;">
    <div style="max-width:1080px;margin:0 auto;display:flex;justify-content:space-between;align-items:center;padding:14px 22px;">
      <div>
        <div style="font-size:18px;font-weight:800;color:#ff9f4a;">Editing: {{ filename }}</div>
        <div style="font-size:12px;color:#9a9a9a;">Save will refresh knowledge index instantly</div>
      </div>
      <a href="{{ url_for('admin_dashboard') }}" style="text-decoration:none;color:#ddd;background:#1d1d1d;border:1px solid #343434;padding:9px 12px;border-radius:10px;font-size:13px;">Back to Dashboard</a>
    </div>
  </header>

  <main style="max-width:1080px;margin:0 auto;padding:20px 22px 32px;">
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        {% for category, message in messages %}
          <div style="margin-bottom:12px;border-radius:10px;padding:12px 14px;font-size:13px;background:{% if category == 'error' %}#3d1414{% else %}#153c20{% endif %};color:{% if category == 'error' %}#ffb3b3{% else %}#aef5c0{% endif %};border:1px solid {% if category == 'error' %}#793131{% else %}#2a6f3d{% endif %};">
            {{ message }}
          </div>
        {% endfor %}
      {% endif %}
    {% endwith %}
    <form method="POST">
      <textarea name="content" spellcheck="false" style="width:100%;height:68vh;background:#111;color:#fff;border:1px solid #333;padding:18px;border-radius:12px;font-family:Consolas,monospace;font-size:14px;line-height:1.55;outline:none;">{{ content }}</textarea>
      <div style="margin-top:14px;display:flex;gap:10px;">
        <button type="submit" style="background:linear-gradient(135deg,#ff7a00,#ff9f4a);color:#fff;border:none;padding:12px 18px;border-radius:10px;cursor:pointer;font-weight:700;">Save Changes</button>
        <a href="{{ url_for('admin_dashboard') }}" style="text-decoration:none;color:#bfbfbf;background:#1d1d1d;border:1px solid #333;padding:11px 15px;border-radius:10px;">Cancel</a>
      </div>
    </form>
  </main>
</body>
</html>
"""

NEW_FILE_UI = """
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Add Knowledge File</title>
</head>
<body style="margin:0;background:#0b0b0b;color:#eee;font-family:'Segoe UI',sans-serif;">
  <header style="position:sticky;top:0;z-index:5;background:rgba(10,10,10,.92);backdrop-filter:blur(8px);border-bottom:1px solid #222;">
    <div style="max-width:860px;margin:0 auto;display:flex;justify-content:space-between;align-items:center;padding:14px 22px;">
      <div style="font-size:18px;font-weight:800;color:#ff9f4a;">Add Knowledge File</div>
      <a href="{{ url_for('admin_dashboard') }}" style="text-decoration:none;color:#ddd;background:#1d1d1d;border:1px solid #343434;padding:9px 12px;border-radius:10px;font-size:13px;">Back</a>
    </div>
  </header>
  <main style="max-width:860px;margin:0 auto;padding:20px 22px 32px;">
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        {% for category, message in messages %}
          <div style="margin-bottom:12px;border-radius:10px;padding:12px 14px;font-size:13px;background:{% if category == 'error' %}#3d1414{% else %}#153c20{% endif %};color:{% if category == 'error' %}#ffb3b3{% else %}#aef5c0{% endif %};border:1px solid {% if category == 'error' %}#793131{% else %}#2a6f3d{% endif %};">
            {{ message }}
          </div>
        {% endfor %}
      {% endif %}
    {% endwith %}
    <form method="POST" style="background:#121212;border:1px solid #242424;border-radius:12px;padding:16px;">
      <label style="font-size:13px;color:#b9b9b9;">File name (without extension)</label>
      <input type="text" name="name" placeholder="example: offers, electronics_faq, support_notes" style="width:100%;padding:12px;margin:8px 0 14px;border-radius:10px;border:1px solid #2f2f2f;background:#0e0e0e;color:#fff;outline:none;" required>
      <label style="font-size:13px;color:#b9b9b9;">Initial content (optional)</label>
      <textarea name="content" spellcheck="false" style="width:100%;height:280px;background:#111;color:#fff;border:1px solid #333;padding:14px;border-radius:10px;font-family:Consolas,monospace;font-size:14px;line-height:1.5;outline:none;"></textarea>
      <div style="margin-top:14px;display:flex;gap:10px;">
        <button type="submit" style="background:linear-gradient(135deg,#ff7a00,#ff9f4a);color:#fff;border:none;padding:12px 18px;border-radius:10px;cursor:pointer;font-weight:700;">Create File</button>
      </div>
      <div style="margin-top:12px;font-size:12px;color:#8f8f8f;">Only safe filenames are allowed: letters, numbers, underscore, hyphen. File is always created in knowledge folder as .txt.</div>
    </form>
  </main>
</body>
</html>
"""

@app.route('/welfog-admin-login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        u = (request.form.get('username') or "").strip()
        p = request.form.get('password') or ""
        user = AdminUser.query.filter_by(username=u).first()

        if user:
            # Support both hashed + legacy plain password and auto-upgrade legacy record
            valid = check_password_hash(user.password, p) if user.password.startswith("pbkdf2:") else (user.password == p)
            if valid:
                if not user.password.startswith("pbkdf2:"):
                    user.password = generate_password_hash(p, method="pbkdf2:sha256")
                    db.session.commit()
                login_user(user)
                return redirect(url_for('admin_dashboard'))

        flash("Invalid username or password.", "error")
    return render_template_string(LOGIN_UI)

@app.route('/welfog-admin')
@login_required
def admin_dashboard():
    if not os.path.exists(KNOWLEDGE_DIR): os.makedirs(KNOWLEDGE_DIR)
    files = get_allowed_knowledge_filenames()
    return render_template_string(DASHBOARD_UI, files=files)

@app.route('/welfog-admin/new-file', methods=['GET', 'POST'])
@login_required
def admin_add_file():
    if request.method == 'POST':
        raw_name = (request.form.get('name') or "").strip()
        initial_content = request.form.get('content') or ""
        safe_name = _safe_knowledge_filename(raw_name)
        if not safe_name:
            flash("Invalid filename. Use letters, numbers, underscore or hyphen.", "error")
            return render_template_string(NEW_FILE_UI)

        filename = f"{safe_name}.txt"
        file_path = os.path.abspath(os.path.join(KNOWLEDGE_DIR, filename))
        if not file_path.startswith(os.path.abspath(KNOWLEDGE_DIR) + os.sep):
            abort(403)
        if os.path.exists(file_path):
            flash("File already exists. Choose a different name.", "error")
            return render_template_string(NEW_FILE_UI)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(initial_content.strip())
        refresh_knowledge_cache()
        flash(f"Created {filename} successfully.", "success")
        return redirect(url_for('admin_dashboard'))
    return render_template_string(NEW_FILE_UI)

@app.route('/welfog-admin/edit/<filename>', methods=['GET', 'POST'])
@login_required
def edit_kb_file(filename):
    allowed_files = set(get_allowed_knowledge_filenames())
    if filename not in allowed_files:
        abort(404)
    file_path = os.path.abspath(os.path.join(KNOWLEDGE_DIR, filename))
    if not file_path.startswith(os.path.abspath(KNOWLEDGE_DIR) + os.sep):
        abort(403)
    if request.method == 'POST':
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(request.form['content'])
        refresh_knowledge_cache()
        flash(f"Saved {filename} and refreshed index.", "success")
        return redirect(url_for('admin_dashboard'))

    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    return render_template_string(EDIT_UI, filename=filename, content=content)

@app.route('/admin-logout')
@login_required
def admin_logout():
    logout_user()
    return redirect(url_for('admin_login'))

def db_store_message(chat_id, sender, message):
    if not chat_id: return
    conn = sqlite3.connect(DB_NAME)
    conn.execute("INSERT INTO messages (chat_id, sender, message) VALUES (?, ?, ?)", (chat_id, sender, message))
    conn.commit()
    conn.close()


def db_get_recent_messages(chat_id, limit=12):
    """Last N messages for this chat (includes current user message once stored)."""
    if not chat_id or limit <= 0:
        return []
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute(
        "SELECT sender, message FROM messages WHERE chat_id = ? ORDER BY id DESC LIMIT ?",
        (chat_id, limit),
    )
    rows = list(reversed(cur.fetchall()))
    conn.close()
    return [{"sender": r[0], "message": r[1]} for r in rows]


def _strip_html_for_context(text: str, max_len: int = 600) -> str:
    if not text:
        return ""
    plain = re.sub(r"<[^>]+>", " ", text)
    plain = re.sub(r"\s+", " ", plain).strip()
    if len(plain) > max_len:
        plain = plain[: max_len - 1].rsplit(" ", 1)[0] + "…"
    return plain


def _format_conversation_for_llm(msgs: list, max_turns: int = 8) -> str:
    """Compact transcript for routing / answering (pronouns, follow-ups)."""
    if not msgs:
        return ""
    tail = msgs[-max_turns:] if len(msgs) > max_turns else msgs
    lines = []
    for m in tail:
        role = "User" if m.get("sender") == "user" else "Assistant"
        content = (m.get("message") or "").strip()
        if m.get("sender") != "user":
            content = _strip_html_for_context(content, max_len=700)
        if not content:
            continue
        lines.append(f"{role}: {content}")
    return "\n".join(lines)


def _conversation_cache_suffix(msgs: list) -> str:
    if not msgs:
        return "0"
    blob = "|".join(f"{m.get('sender')}:{(m.get('message') or '')[:160]}" for m in msgs[-8:])
    return str(abs(hash(blob)) % (10**12))


def build_retrieval_query(msg_en: str, conv_block: str, original_msg: str) -> str:
    """Combine recent chat with the latest question so embeddings match follow-ups."""
    base = (msg_en or "").strip() or (original_msg or "").strip()
    if not conv_block.strip():
        return base
    tail = conv_block[-1400:] if len(conv_block) > 1400 else conv_block
    return f"{tail}\n\nCurrent question: {(original_msg or '').strip()}".strip()


# HTML = """
# <!DOCTYPE html>
# <html>
# <head><title>Welfog Agent</title></head>
# <body><h2>Welfog AI Agent is Running!</h2></body>
# </html>
# """

# ================= CONTEXT / STATE MANAGEMENT =================
user_contexts = {}

def reset_context(ctx):
    ctx["intent"] = None
    ctx["awaiting"] = None
    ctx["data"] = {}
    ctx["last"] = None
    ctx["order_id"] = None

def extract_order_id(msg):
    match = re.search(r"\b[a-zA-Z0-9]{6,20}\b", msg)
    return match.group().upper() if match else None

model = SentenceTransformer('all-MiniLM-L6-v2')
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ================= PERF: common embeddings & caches =================
GREETINGS = ["hi", "hello", "hii", "hey", "namaste"]
GREETINGS_VECS = model.encode(GREETINGS)

# Very small in-memory cache (avoid repeat Groq + KB work)
_cache = {}
_cache_ttl_sec = 60


def _cache_get(key):
    try:
        item = _cache.get(key)
        if not item:
            return None
        ts, val = item
        if (datetime.now().timestamp() - ts) > _cache_ttl_sec:
            _cache.pop(key, None)
            return None
        return val
    except Exception:
        return None


def _cache_set(key, val):
    try:
        # keep cache small
        if len(_cache) > 300:
            _cache.clear()
        _cache[key] = (datetime.now().timestamp(), val)
    except Exception:
        pass


# ================= KNOWLEDGE BASE =================
_KB_SNAPSHOT = ""

def _safe_knowledge_filename(name: str) -> str:
    if not name:
        return ""
    cleaned = name.strip().lower().replace(" ", "_")
    cleaned = re.sub(r"[^a-z0-9_-]", "", cleaned)
    if not cleaned or len(cleaned) > 64:
        return ""
    return cleaned

def get_runtime_knowledge_files():
    """
    Auto-discovers all .txt files from knowledge folder.
    No hardcoded mapping required.
    """
    runtime = {}
    if not os.path.exists(KNOWLEDGE_DIR):
        os.makedirs(KNOWLEDGE_DIR, exist_ok=True)
        return runtime
    for filename in sorted(os.listdir(KNOWLEDGE_DIR)):
        if not filename.endswith(".txt"):
            continue
        file_path = os.path.join(KNOWLEDGE_DIR, filename)
        if not os.path.isfile(file_path):
            continue
        key_base = os.path.splitext(filename)[0].replace("-", "_").replace(" ", "_").lower()
        key = re.sub(r"[^a-z0-9_]", "", key_base)
        if not key:
            continue
        # Avoid key collisions if two files normalize to same key
        if key in runtime:
            n = 2
            while f"{key}_{n}" in runtime:
                n += 1
            key = f"{key}_{n}"
        runtime[key] = file_path
    return runtime

def get_allowed_knowledge_filenames():
    return sorted({os.path.basename(path) for path in get_runtime_knowledge_files().values() if path.endswith(".txt")})

def _compute_kb_snapshot(runtime_files):
    parts = []
    for key, path in sorted(runtime_files.items()):
        try:
            st = os.stat(path)
            parts.append(f"{key}:{st.st_size}:{st.st_mtime_ns}")
        except OSError:
            parts.append(f"{key}:missing")
    return "|".join(parts)


def _parse_system_messages(text: str):
    """
    Parses lines like: key = value
    Ignores empty lines and headings.
    """
    out = {}
    if not text:
        return out
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            continue
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip()
        if k and v:
            out[k] = v
    return out


def _split_kb_chunks(text: str):
    """
    Split knowledge files into embedding chunks. Short title-only blocks are merged
    with the following paragraph so retrieval returns real content, not just headings.
    """
    if not text:
        return []
    parts = []
    for c in text.split("\n\n"):
        c = c.strip().replace("\n", "<br>")
        if len(c) < 12:
            continue
        parts.append(c)
    if not parts:
        return []
    merged = []
    acc = parts[0]
    for p in parts[1:]:
        if len(acc) < 160:
            acc = acc + "<br><br>" + p
        else:
            merged.append(acc)
            acc = p
    merged.append(acc)
    out = []
    max_len, step = 950, 780
    for ch in merged:
        if len(ch) <= max_len:
            out.append(ch)
            continue
        i = 0
        while i < len(ch):
            piece = ch[i : i + max_len]
            if len(piece) >= 20:
                out.append(piece)
            i += step
    return out


def load_knowledge_index(runtime_files=None):
    chunks_by_key = {}
    vectors_by_key = {}
    all_chunks_local = []
    all_sources_local = []

    files_map = runtime_files if runtime_files is not None else get_runtime_knowledge_files()
    for k, path in files_map.items():
        try:
            if not os.path.exists(path):
                print(f"⚠️ Warning: File missing at {path}")
                chunks_by_key[k] = []
                vectors_by_key[k] = []
                continue

            with open(path, "r", encoding="utf-8") as f:
                content = f.read()

            chunks = _split_kb_chunks(content)
            chunks_by_key[k] = chunks
            if chunks:
                vecs = model.encode(chunks)
                vectors_by_key[k] = vecs
                all_chunks_local.extend(chunks)
                all_sources_local.extend([k] * len(chunks))
            else:
                vectors_by_key[k] = []
        except Exception as e:
            print(f"Error loading {path}: {e}")
            chunks_by_key[k] = []
            vectors_by_key[k] = []

    all_vectors_local = model.encode(all_chunks_local) if all_chunks_local else []
    return chunks_by_key, vectors_by_key, all_chunks_local, all_vectors_local, all_sources_local

def refresh_knowledge_cache():
    global kb_chunks_by_key, kb_vectors_by_key, all_chunks, all_vectors, all_chunk_sources, _SYSTEM_MESSAGES, _KB_SNAPSHOT
    runtime_files = get_runtime_knowledge_files()
    kb_chunks_by_key, kb_vectors_by_key, all_chunks, all_vectors, all_chunk_sources = load_knowledge_index(runtime_files)
    _KB_SNAPSHOT = _compute_kb_snapshot(runtime_files)
    try:
        sys_path = runtime_files.get("system_messages")
        if sys_path and os.path.exists(sys_path):
            with open(sys_path, "r", encoding="utf-8") as f:
                _SYSTEM_MESSAGES = _parse_system_messages(f.read())
        else:
            _SYSTEM_MESSAGES = {}
    except Exception as e:
        print("System messages reload error:", e)

def ensure_knowledge_cache_fresh():
    global _KB_SNAPSHOT
    runtime_files = get_runtime_knowledge_files()
    latest_snapshot = _compute_kb_snapshot(runtime_files)
    if latest_snapshot != _KB_SNAPSHOT:
        refresh_knowledge_cache()
        _cache.clear()


_SYSTEM_MESSAGES = {}
refresh_knowledge_cache()

INTERNAL_KB_KEYS = {"welfog_api", "system_messages"}


def get_customer_kb_keys():
    return [k for k in get_runtime_knowledge_files().keys() if k not in INTERNAL_KB_KEYS]


def sysmsg(key: str, **kwargs):
    """
    Fetch a user-facing message from knowledge files.
    Supports {placeholders}.
    """
    txt = _SYSTEM_MESSAGES.get(key, "")
    if not txt:
        return ""
    try:
        return txt.format(**kwargs)
    except Exception:
        return txt



def get_knowledge_context(query, keys=None, top_k=3, min_score=0.15):
    """
    If keys provided, search within those knowledge files only; else search all.
    Returns an HTML string to inject into the system prompt.
    """
    if not all_chunks:
        return ""

    # Cache KB context because same query repeats often (especially with translations)
    cache_key = f"kbctx::{query}::{','.join(keys) if keys else 'ALL'}::{top_k}::{min_score}"
    cached = _cache_get(cache_key)
    if cached is not None:
        return cached

    if keys:
        keys = [k for k in keys if k in kb_chunks_by_key]
        scoped_chunks = []
        scoped_vectors_list = []
        scoped_sources = []
        for k in keys:
            ch = kb_chunks_by_key.get(k)
            if not ch:
                continue
            vec = kb_vectors_by_key.get(k)
            if vec is None:
                continue
            if len(ch) == len(vec):
                scoped_chunks.extend(ch)
                scoped_vectors_list.append(vec)
                scoped_sources.extend([k] * len(ch))
        if not scoped_chunks:
            _cache_set(cache_key, "")
            return ""

        # concat precomputed vectors (fast)
        import numpy as np
        scoped_vectors = np.vstack(scoped_vectors_list) if len(scoped_vectors_list) > 1 else scoped_vectors_list[0]

        query_vec = model.encode([query])
        scores = cosine_similarity(query_vec, scoped_vectors)[0]
        top_indices = scores.argsort()[-top_k:][::-1]
        picked = [(scoped_sources[i], scoped_chunks[i], float(scores[i])) for i in top_indices if scores[i] > min_score]
    else:
        query_vec = model.encode([query])
        scores = cosine_similarity(query_vec, all_vectors)[0]
        top_indices = scores.argsort()[-top_k:][::-1]
        picked = [(all_chunk_sources[i], all_chunks[i], float(scores[i])) for i in top_indices if scores[i] > min_score]

    if not picked:
        return ""

    # Include sources so the model knows which file the context came from.
    out = []
    for src, chunk, sc in picked:
        out.append(f"[source={src} score={sc:.2f}] {chunk}")
    result = "<br><br>".join(out)
    _cache_set(cache_key, result)
    return result


# ================= 🚀 1.5 DIRECT KB SEARCH 🚀 =================
def direct_kb_search(query, keys=None, min_score=0.40):
    if not all_chunks:
        return None
    picked = None
    if keys:
        keys = [k for k in keys if k in kb_chunks_by_key]
        scoped_chunks = []
        scoped_vectors_list = []
        for k in keys:
            ch = kb_chunks_by_key.get(k) or []
            vec = kb_vectors_by_key.get(k)
            if ch and vec is not None and len(ch) == len(vec):
                scoped_chunks.extend(ch)
                scoped_vectors_list.append(vec)
        if not scoped_chunks:
            return None
        import numpy as np
        scoped_vectors = np.vstack(scoped_vectors_list) if len(scoped_vectors_list) > 1 else scoped_vectors_list[0]
        query_vec = model.encode([query])
        scores = cosine_similarity(query_vec, scoped_vectors)[0]
        best_idx = scores.argmax()
        if scores[best_idx] > min_score:
            picked = scoped_chunks[best_idx]
    else:
        query_vec = model.encode([query])
        scores = cosine_similarity(query_vec, all_vectors)[0]
        best_idx = scores.argmax()
        if scores[best_idx] > min_score:
            picked = all_chunks[best_idx]

    if picked:
        cleaned = re.sub(r"\[source=.*?score=.*?\]\s*", "", picked, flags=re.IGNORECASE)
        return f"According to our knowledge base:<br><b>{cleaned}</b>"
    return None


# ================= ⚡ ULTRA-FAST INSTANT ROUTER (Dumb & Fast) ⚡ =================
def smart_instant_router(original_msg, english_msg):
    text = f" {original_msg} {english_msg} ".lower()
    words = original_msg.lower().split()

    # 1. INSTANT GREETINGS CHECK (Static)
    greetings = ["hi", "hello","hii","heyy", "hey", "namaste", "bhai", "sun", "suno", "brother", "hiii"]
    if len(words) <= 3 and all(w in greetings for w in words):
        return {"action": "text", "data": sysmsg("greeting")}

    # 2. INSTANT REJECTION & OFF-TOPIC (Static Guardrails)
    competitors = ["amazon", "flipkart", "myntra", "meesho", "ajio", "snapdeal", "shopsy", "glowroad", "zomato", "swiggy", "groww"]
    off_topics = [
        "school", "college", "university", "exam", "homework", "free fire", "pubg", "bgmi", "game", "movie", "song",
        "cricket", "football", "ipl", "weather", "politics", "election", "bollywood", "astrology", "kundli",
        "girlfriend", "boyfriend", "breakup", "joke", "funny", "recipe", "cooking",
    ]

    if any(f" {c} " in text for c in competitors):
        return {"action": "reject", "data": "I’m here to assist you with Welfog 😊\nI don't have information about other companies."}

    if any(f" {ot} " in text for ot in off_topics):
        polite = sysmsg("off_topic_polite")
        return {"action": "reject", "data": polite or "I'm a Welfog assistant and can only help with Welfog shopping and support."}

    # 3. DIRECT ORDER ID ENTRY (Regex - 100% accurate; 6-digit PIN is not an order id)
    if len(words) == 1 and re.match(r"^[a-z0-9]{6,20}$", words[0]):
        w0 = words[0].lower()
        if re.fullmatch(r"[1-9]\d{5}", w0):
            return None
        return {"action": "direct_order_id", "order_id": words[0].upper()}

    # 4. INSTANT SOCIAL MEDIA LINKS
    is_social = any(w in text for w in ["instagram", "insta", "linkedin", "facebook", "youtube", "twitter"])
    is_welfog_context = any(w in text for w in ["welfog", "company", "official", "our", "your", "apna"])
    if is_social:
        if not is_welfog_context and len(words) > 3:
            return {"action": "reject", "data": "I can only provide official social media links for Welfog. 😊"}
        else:
            links = []
            btn_style = "display: block; text-align: center; max-width: 220px; margin-bottom: 12px; color: white; padding: 10px 15px; text-decoration: none; border-radius: 25px; font-weight: bold; font-size: 14px; box-shadow: 0 4px 6px rgba(0,0,0,0.15);"
            if "instagram" in text or "insta" in text:
                links.append(f"<a href='https://www.instagram.com/welfog_online/' target='_blank' style='{btn_style} background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);'>📸 Instagram</a>")
            if "twitter" in text or " x " in text:
                links.append(f"<a href='https://x.com/welfog' target='_blank' style='{btn_style} background: linear-gradient(to right, #14171A, #000000);'>🐦 Twitter (X)</a>")
            if "facebook" in text or " fb " in text:
                links.append(f"<a href='https://www.facebook.com/people/welfog/' target='_blank' style='{btn_style} background: linear-gradient(to right, #1877F2, #0b50a8);'>📘 Facebook</a>")
            if "youtube" in text:
                links.append(f"<a href='https://www.youtube.com/@welfog_online' target='_blank' style='{btn_style} background: linear-gradient(to right, #FF0000, #b30000);'>▶️ YouTube</a>")
            if "linkedin" in text or "linkdin" in text:
                links.append(f"<a href='https://www.linkedin.com/company/welfog/' target='_blank' style='{btn_style} background: linear-gradient(to right, #0077B5, #005582);'>💼 LinkedIn</a>")
            if links:
                return {"action": "text", "data": "<div style='font-size: 14px; color: #333; margin-bottom: 12px;'><b>Here are our official links:</b></div>" + "".join(links)}
    # 🔥 SAB KUCH HATA DIYA! Koi keyword matching nahi. 
    # Ab chahe Telugu me puche ya Hindi me, direct AI Brain decide karega!
    return None


# ================= LANGUAGE HELPERS =================
ALLOWED_LANGS = ["en","hi","gu","pa","ta","te","mr","ml","kn","bn","ur","hinglish"]

def detect_language(msg):
    try:
        lang = detect(msg)
        if lang == "en" and any(word in msg.lower() for word in ["bhai","kya","hai","kar","kr","nahi","kyu","kaise", "mera", "kab", "tak", "kitne", "din", "kese"]):
            return "hi"
        return lang if lang in ALLOWED_LANGS else "en"
    except:
        return "en"

def to_en(text):
    try:
        return GoogleTranslator(source='auto', target='en').translate(text)
    except:
        return text

def to_user(text, lang):
    if lang == "en": return text
    try:
        return GoogleTranslator(source='en', target=lang).translate(text)
    except:
        return text


# --- Roman Hindi / Hinglish product understanding (fills gaps when Groq returns wrong intent) ---
_PRODUCT_QUERY_STOPWORDS = frozenset({
    "h", "hai", "he", "ho", "hun", "hoon", "ky", "kya", "ka", "ke", "ki", "ko", "me", "mai", "main",
    "par", "pe", "se", "tak", "kab", "kaise", "kyu", "kyun", "wala", "wale", "wali", "walon",
    "welfog", "app", "website", "online", "pls", "please", "bhai", "yr", "yrr", "yaar", "dear",
    "mil", "milega", "milegi", "milta", "milti", "milen", "sakta", "skta", "sakti", "skti", "sakte",
    "dikha", "dikhaa", "dikhao", "dikhaan", "dikhado", "dikhaana", "dikhaaoo", "de", "do", "dena", "dedo",
    "bata", "batao", "btao", "show", "send", "list", "saare", "sab", "all", "any", "koi", "kuch",
    "chahiye", "chiye", "chaahiye", "lenaa", "lena", "len", "lun", "buy", "need", "want", "looking",
    "for", "the", "a", "an", "is", "are", "there", "have", "has", "stock", "available", "get",
    "categories", "category", "categor", "id", "name",
})

_POLICY_QUESTION_HINTS = frozenset({
    "refund", "return", "payment", "track", "order id", "orderid", "cancel", "policy", "complaint",
    "support", "grievance", "invoice", "delivery time", "shipping time", "damaged", "wrong item",
})


def extract_pincode_from_text(text: str) -> str:
    """First valid 6-digit Indian PIN (leading digit 1–9) in the message, else ''."""
    if not text:
        return ""
    m = re.search(r"\b[1-9]\d{5}\b", text)
    return m.group(0) if m else ""


def _text_is_order_tracking_intent(t: str) -> bool:
    """Track/status of an existing order — not 'can I place an order from X'."""
    tl = f" {t.lower()} "
    markers = (
        "track", "tracking", "order status", "order id", "orderid", "where is my order",
        "where my order", "delivery status", "shipment", "kab aayega", "kab aaega",
        "kab milega", "kahan hai order", "order kahan", "parcel", "package kahan",
    )
    return any(m in tl for m in markers)


def _text_has_delivery_or_order_area_intent(t: str) -> bool:
    """
    Delivery serviceability / can I order from this place — Roman Hindi + English.
    Must run BEFORE broad 'product' heuristics so city + delivery does not hit product search.
    """
    tl = f" {t.lower()} "
    if extract_pincode_from_text(t):
        return True
    if any(x in tl for x in [" pincode", " pin code", " pin-code", "zip code", "postal code"]):
        return True
    if any(
        x in tl
        for x in [
            "delivery", "delevery", "delivry", "deliver", "shipping", "courier", "dispatch",
            "ship to", "ship kar",
        ]
    ):
        return True
    if any(
        x in tl
        for x in [
            "order kr", "order kar", "order skt", "order sak", "order skte", "order sakte",
            "order kru", "order karu", "place order", "order dal", "order dunga",
            "mangwa", "mangwa sak", "manga sak", "mangwa skt", "mang skt",
            "aa jayegi", "aa jaayegi", "aayegi", "aayega", "pahuch", "pohuch", "pahuchega",
            "de deg", "de dega", "dedega", "dega na", "milegi delivery", "delivery milegi",
            "service area", "deliver ho", "deliver ho sak", "serviceable",
        ]
    ):
        return True
    if "welfog" in tl and any(x in tl for x in ["use kr", "use kar", "use skt", "use sak", "chal sak", "chalega", "chlega"]):
        if any(x in tl for x in [" se ", " me ", " mein ", "wale", "walo", "city", " pin", " pincode"]):
            return True
    return False


def _text_has_platform_overview_intent(t: str) -> bool:
    """What is on Welfog / how many product types — not a SKU search."""
    tl = t.lower()
    if any(x in tl for x in ["kitne product", "kitne products", "how many product", "how many products"]):
        return True
    if "kya kya" in tl and any(x in tl for x in ["mil", "milega", "milta", "milegi", "milti", "milt", "available"]):
        return True
    if any(x in tl for x in ["what do you sell", "what can i buy", "what all can i", "what is sold"]):
        return True
    if "welfog" in tl and any(x in tl for x in ["kya kya", "kya hai", "kya milta", "about welfog", "pe kya", "par kya", "me kya", "mein kya"]):
        if not _text_has_product_shopping_intent(tl) and "order track" not in tl:
            return True
    return False


def _merge_extracted_pincode(original_msg: str, msg_en: str, ai_data: dict) -> None:
    if not ai_data:
        return
    cur = (ai_data.get("extracted_pincode") or "").strip()
    if cur and re.fullmatch(r"[1-9]\d{5}", cur):
        return
    pin = extract_pincode_from_text(original_msg) or extract_pincode_from_text(msg_en)
    if pin:
        ai_data["extracted_pincode"] = pin


def _looks_like_conversational_followup(original_msg: str, msg_en: str) -> bool:
    """
    Short follow-ups (uska/uske, 'kya karta hai', 'batao') refer to the last topic — not a product SKU search.
    """
    combined = f" {original_msg} {msg_en} ".lower()
    pronoun = (
        " uska ", " uske ", " uski ", " unka ", " unke ", " unki ", " iska ", " iske ", " iski ",
        " inka ", " inke ", " inki ", " yeh ", " ye ", " woh ", " wo ", " is ", " un ",
    )
    explain = (
        "kya karta", "kya karti", "kya karte", " krta ", " krti ", " krte ", " karte ",
        "kaam kya", "kam kya", "what does", "what do ", "how does", "explain", "details",
        "aur bata", "aur btao", "aur batao", " bta ", " btao ", " batao ", "tell me more",
        "iske bare", "iske baare", "uske bare", "uske baare", "iske bar", "uske bar",
    )
    if any(p in combined for p in pronoun) and any(e in combined for e in explain):
        return True
    if any(p in combined for p in pronoun) and any(x in combined for x in (" bta", "btao", "batao", "bata", "detail")):
        return True
    return False


def _text_has_product_shopping_intent(t: str) -> bool:
    """True if message reads like buy/show/availability in English or Roman Hindi."""
    t = f" {t.lower()} "
    non_product_hints = (
        " about ", "department", "departments", "team ", "teams ", "staff ", "company ",
        "policy", "policies", "information", "details",
    )
    if any(h in t for h in non_product_hints):
        return False
    en_markers = (
        "show", "buy", "need", "want", "looking for", " search ", " find ", "price ", " rate ",
        "cheap", "under rs", "under ₹", "purchase", "shop ",
    )
    if any(m in t for m in en_markers):
        return True
    hi_markers = (
        "dikha", "dikhao", "dikh", "dikhaa", "dikhaan",
        "milta", "milti", "milega", "milegi",
        "mil sk", "mil sak", "mile sk", "mile sak",
        "sakta", "skta", "sakti", "skti",
        "chahiye", "chiye", "chaahiye",
        " hai kya", " h kya", " hai ky", " h ky",
        "kidhar", "kahan", "kha se", "kb milega",
    )
    return any(m in t for m in hi_markers)


def _looks_like_browse_all_categories_message(t: str) -> bool:
    t = t.lower()
    return any(
        x in t
        for x in (
            "all categor", "saari categor", "sari categor", "category list", "categories list",
            "list of categor", "konsi categor", "kaun si categor", "browse categor", "har categor",
        )
    )


def _looks_like_policy_faq_message(t: str) -> bool:
    tl = t.lower()
    return any(h in tl for h in _POLICY_QUESTION_HINTS)


def extract_product_search_query(original_msg: str, msg_en: str, ai_search_query=None) -> str:
    """
    Prefer a sensible model-provided search_query; otherwise strip Roman-Hindi filler
    and keep product nouns/brands (e.g. 'cover h ky' -> 'cover').
    """
    sq = (ai_search_query or "").strip()
    if sq and len(sq) >= 2 and sq.lower() not in ("product", "item", "thing", "na", "n/a", "none", "null"):
        return sq
    combined = f"{original_msg} {msg_en}".lower()
    tokens = re.findall(r"[a-z0-9]+", combined)
    kept: list[str] = []
    seen: set[str] = set()
    for w in tokens:
        if len(w) < 2 or w in _PRODUCT_QUERY_STOPWORDS:
            continue
        if w not in seen:
            seen.add(w)
            kept.append(w)
    return " ".join(kept).strip()


def apply_hinglish_product_fixes(original_msg: str, msg_en: str, ai_data: dict) -> None:
    """
    Correct common mis-routes: availability questions in Hinglish must hit product search,
    not categories list or a generic FAQ paragraph.
    """
    if not ai_data:
        return
    intent = ai_data.get("intent")
    if intent == "out_of_domain" or not ai_data.get("is_welfog_related", True):
        return

    if _looks_like_conversational_followup(original_msg, msg_en):
        if ai_data.get("intent") == "product":
            ai_data["intent"] = "general"
            ai_data["search_query"] = ""
    intent = ai_data.get("intent")

    combined = f"{original_msg} {msg_en}"
    comb_low = combined.lower()
    if _text_has_delivery_or_order_area_intent(comb_low):
        if intent == "product":
            ai_data["intent"] = "pincode_check"
            ai_data["search_query"] = ""
        return
    if _text_has_platform_overview_intent(comb_low):
        if intent == "product":
            ai_data["intent"] = "general"
            ai_data["search_query"] = ""
        return
    extracted = extract_product_search_query(original_msg, msg_en, ai_data.get("search_query"))

    if intent == "categories" and extracted and not _looks_like_browse_all_categories_message(combined):
        tl = combined.lower()
        short_concrete = len(re.findall(r"[a-z0-9]+", tl)) <= 5 and "categor" not in tl
        if _text_has_product_shopping_intent(combined) or short_concrete:
            ai_data["intent"] = "product"
            ai_data["search_query"] = extracted
            return

    if (
        intent == "general"
        and extracted
        and _text_has_product_shopping_intent(combined)
        and not _looks_like_conversational_followup(original_msg, msg_en)
    ):
        if not _looks_like_policy_faq_message(combined):
            ai_data["intent"] = "product"
            ai_data["search_query"] = extracted
            return

    if intent == "product":
        cur = (ai_data.get("search_query") or "").strip()
        if not cur or len(cur) < 2 or cur.lower() in ("product", "item", "thing"):
            if extracted:
                ai_data["search_query"] = extracted


# ================= EXTERNAL APIs =================
def fetch_api(endpoint, order_id):
    try:
        res = requests.get(f"http://localhost:5000/{endpoint}/{order_id}", timeout=10)
        return res.json() if res.status_code == 200 else None
    except:
        return None


def _normalize_color(text: str):
    if not text:
        return None
    t = text.lower()
    # common colors (extend as needed)
    if "multicolor" in t or "multi color" in t:
        return "Multicolor"
    if "black" in t:
        return "Black"
    if "white" in t:
        return "White"
    if "red" in t:
        return "Red"
    if "blue" in t:
        return "Blue"
    if "green" in t:
        return "Green"
    if "yellow" in t:
        return "Yellow"
    if "pink" in t:
        return "Pink"
    if "purple" in t:
        return "Purple"
    if "brown" in t:
        return "Brown"
    if "grey" in t or "gray" in t:
        return "Grey"
    return None

# ================= EXTERNAL APIs =================
def fetch_products_from_api(query, category_id=None, color=None, page=1):
    # Allow category-only browse (query can be empty if category_id is provided)
    if (not query or not query.strip()) and not category_id:
        return []
        
    query = (query or "").lower()
    # 1. CLEAN QUERY (LLM agar kuch chhod de toh yahan saaf karo)
    stop_words = ["all", "show", "me", "the", "a", "an", "buy", "need", "want", "dikha", "chahiye", "saare", "mere", "ko", "bhai"]
    q_words = [w for w in query.split() if w not in stop_words]
    clean_query = " ".join(q_words)
    if not clean_query: clean_query = query

    # 2. 🔥 THE "ANTI-CATEGORY" LOGIC (Super Smart Filter)
    anti_words = []
    # Agar user ne 'cover' ya 'case' nahi manga, toh cover mat dikhao!
    if "cover" not in clean_query and "case" not in clean_query and "bumper" not in clean_query:
        anti_words.extend(["cover", "case", "bumper", "glass", "protector"])
    # Agar user ne charger/cable nahi manga, toh wo mat dikhao!
    if "charger" not in clean_query and "cable" not in clean_query and "adapter" not in clean_query:
        anti_words.extend(["charger", "cable", "adapter", "usb"])

    brands = ["samsung", "iphone", "apple", "vivo", "oppo", "realme", "mi", "xiaomi", "oneplus", "durex"]
    query_brands = [w for w in q_words if w in brands]

    try:
        url = "https://welfogapi.welfog.com/api/v2/products/search"
        params = {"page": page or 1, "latitude": "", "longitude": ""}
        if clean_query.strip():
            params["name"] = clean_query
        if category_id:
            params["categories"] = str(category_id)
        if color:
            params["color"] = color

        res = requests.get(url, params=params, timeout=10)
        data = res.json() if res.status_code == 200 else {}
        products_list = data.get("data", [])
        
        # FALLBACK SEARCH
        if not products_list and len(q_words) > 1 and not category_id:
            fallback_word = q_words[0] if any(b in q_words[0] for b in brands) else q_words[-1]
            res = requests.get(url, params={"page": 1, "name": fallback_word, "latitude": "", "longitude": ""}, timeout=10)
            data = res.json() if res.status_code == 200 else {}
            products_list = data.get("data", [])

        if not products_list: 
            return []

        IMAGE_BASE_URL = "https://d1f02fefkbso7w.cloudfront.net/"
        scored_products = []

        for p in products_list:
            name = p.get("name") or sysmsg("default_product_card_title")
            name_lower = name.lower()
            
            # 🔥 STRICT BRAND CHECK
            if query_brands and not any(qb in name_lower for qb in query_brands):
                continue
                
            # 🔥 STRICT ANTI-WORD CHECK (Mobile manga toh Cover reject)
            # Dhyan rahe exact word match ho, naam ka hissa nahi
            product_words = name_lower.split()
            if any(aw in product_words for aw in anti_words):
                continue

            # SCORING SYSTEM
            score = 0
            for word in q_words:
                singular = word[:-1] if word.endswith('s') else word
                if word in name_lower or singular in name_lower:
                    score += 2
                elif len(word) >= 4:
                    for n_word in product_words:
                        if abs(len(word) - len(n_word)) <= 1:
                            match_count = sum(1 for a, b in zip(word, n_word) if a == b)
                            if match_count / len(word) >= 0.75:
                                score += 1
                                break
            
            if score > 0 or not q_words:
                scored_products.append({
                    "name": name,
                    "price": p.get("main_price") or sysmsg("na_price"),
                    "image": (IMAGE_BASE_URL + p.get("thumbnail_image", "").lstrip('/')) if p.get("thumbnail_image") else "",
                    "link": f"https://welfog.com/product/{p.get('slug', '')}" if p.get("slug") else "https://welfog.com",
                    "score": score
                })

        scored_products.sort(key=lambda x: x['score'], reverse=True)
        return scored_products[:5]

    except Exception as e:
        print(f"Product Fetch Error: {e}")
        return []    


def check_pincode_delivery(pincode):
    try:
        url = "https://welfogapi.welfog.com/api/v2/pincode/check_pincode"
        # Pincode ko hamesha string mein convert karke bhejo
        payload = {'pincode': str(pincode)} 
        
        # API hit
        res = requests.post(url, data=payload, timeout=10)
        
        if res.status_code == 200:
            return res.json()
        else:
            print(f"⚠️ API Status Error: {res.status_code}")
            return None
    except Exception as e:
        print(f"❌ Pincode API Exception: {e}")
        return None


def fetch_nav_categories():
    try:
        url = "https://welfogapi.welfog.com/api/nav_cat_data"
        res = requests.get(url, timeout=10)
        return res.json() if res.status_code == 200 else None
    except Exception as e:
        print(f"❌ Categories API Exception: {e}")
        return None


# -------- Category name -> id resolver (cached) --------
_navcat_cache = {"ts": 0.0, "map": {}}
_navcat_ttl_sec = 600  # 10 minutes


def _normalize_cat_name(s: str):
    if not s:
        return ""
    s = str(s).lower().strip()
    s = re.sub(r"[^a-z0-9& ]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def get_category_id_from_text(text: str, ctx=None):
    """
    Returns category_id (string) if any category name matches the text.
    Uses ctx.categories_map first, else cached nav_cat_data map.
    """
    t = _normalize_cat_name(text)
    if not t:
        return None

    def _fuzzy_lookup(input_text: str, mapping: dict):
        if not mapping:
            return None
        # exact / contains match
        for name, cid in mapping.items():
            if name and name in input_text:
                return str(cid)
        # token-level typo match (e.g. electonics -> electronics)
        words = [w for w in input_text.split() if len(w) >= 4]
        names = list(mapping.keys())
        for w in words:
            best = difflib.get_close_matches(w, names, n=1, cutoff=0.82)
            if best:
                return str(mapping[best[0]])
        # whole phrase fuzzy
        phrase = difflib.get_close_matches(input_text, names, n=1, cutoff=0.75)
        if phrase:
            return str(mapping[phrase[0]])
        return None

    # 1) from ctx map (fastest)
    if ctx:
        cat_map = (ctx.get("data") or {}).get("categories_map") or {}
        if cat_map:
            normalized_map = {}
            for name, cid in cat_map.items():
                nn = _normalize_cat_name(name)
                if nn:
                    normalized_map[nn] = str(cid)
            hit = _fuzzy_lookup(t, normalized_map)
            if hit:
                return hit

    # 2) from global cache
    now_ts = datetime.now().timestamp()
    cached_map = _navcat_cache.get("map") or {}
    if cached_map and (now_ts - float(_navcat_cache.get("ts") or 0)) < _navcat_ttl_sec:
        hit = _fuzzy_lookup(t, cached_map)
        if hit:
            return hit
        return None

    # 3) refresh cache from API
    cats = fetch_nav_categories()
    items = []
    if isinstance(cats, dict):
        for key in ["data", "categories", "result"]:
            if isinstance(cats.get(key), list):
                items = cats.get(key)
                break
    elif isinstance(cats, list):
        items = cats

    new_map = {}
    for it in items:
        if not isinstance(it, dict):
            continue
        cid = it.get("id") or it.get("category_id") or it.get("cat_id")
        name = it.get("name") or it.get("title") or it.get("category_name")
        nn = _normalize_cat_name(name)
        if cid and nn:
            new_map[nn] = str(cid)

    _navcat_cache["ts"] = now_ts
    _navcat_cache["map"] = new_map

    hit = _fuzzy_lookup(t, new_map)
    if hit:
        return hit
    return None


def fetch_today_deals(latitude="34.04505157470703", longitude="78.38422393798828"):
    try:
        url = "https://welfogapi.welfog.com/api/today_deal"
        res = requests.get(url, params={"latitude": latitude, "longitude": longitude}, timeout=10)
        return res.json() if res.status_code == 200 else None
    except Exception as e:
        print(f"❌ Deals API Exception: {e}")
        return None


def fetch_category_wise_feed(page=1, latitude="34.04505157470703", longitude="78.38422393798828"):
    try:
        url = "https://welfogapi.welfog.com/api/cat_wise_product_show"
        res = requests.get(url, params={"latitude": latitude, "longitude": longitude, "page": page}, timeout=10)
        return res.json() if res.status_code == 200 else None
    except Exception as e:
        print(f"❌ Cat-wise API Exception: {e}")
        return None


def ai_brain_route(user_msg, conversation_context: str = ""):
    """
    Step 1: Use Groq to understand the user message (any language),
    decide intent + which knowledge files should be used for grounding.
    """
    try:
        groq_api_key = os.getenv("GROQ_API_KEY") 
        if not groq_api_key:
            print("⚠️ ERROR: Groq API Key nahi mili! .env file check kar.")
            return None

        url = "https://api.groq.com/openai/v1/chat/completions"
        model_name = "llama-3.1-8b-instant" 

        kb_keys_list = ", ".join([f'"{k}"' for k in get_runtime_knowledge_files().keys()])
        system_prompt = f"""You are 'Welfog AI', an intelligent e-commerce assistant for Welfog.
Your job in this step is ONLY routing + understanding. Return ONLY a valid JSON object.

Available knowledge file keys (choose from these only):
[{kb_keys_list}]

JSON SCHEMA:
{{
  "reasoning": "Analyze the user's intent step-by-step.",
  "intent": "product" | "order" | "refund" | "payment" | "seller" | "pincode_check" | "deals" | "categories" | "category_feed" | "general" | "out_of_domain",
  "kb_keys": ["One or more knowledge keys to use for grounding"],
  "search_query": "Clean product name if product intent, else empty",
  "extracted_pincode": "Extract the 6-digit PIN code if the user provides one, else empty string",
  "needs_order_id": true/false,
  "is_welfog_related": true/false
}}

CRITICAL ROUTING RULES:
1) DEALS/OFFERS: If user asks for deals/offers/discount/today deals -> intent="deals", kb_keys MUST include "welfog_api".
2) CATEGORIES LIST: ONLY if user clearly wants the full department list ("all categories", "category list", "saari category", "browse all categories") -> intent="categories", kb_keys MUST include "welfog_api".
   NEVER use intent="categories" for a specific item/brand/stock question (e.g. Roman Hindi "durex h ky", "cover hai kya", "pen milta hai") — those are PRODUCT searches.
2b) CATEGORY-WISE FEED: If user asks "category wise products", "home page products", "browse by category", "trending by category" -> intent="category_feed", kb_keys MUST include "welfog_api".
3) PINCODE / DELIVERY AREA: If the user asks whether Welfog delivers to a place, if they can order from a city/area, serviceability, or uses Roman Hindi such as "delivery chahiye", "X se order kr sakta", "aa jayegi delivery", "de dega na delivery", "pincode", or gives a 6-digit Indian PIN -> intent="pincode_check". Put the PIN in extracted_pincode when present, else "". kb_keys MUST include "shipping", "faqs", and usually "company".
   Do NOT use intent="product" when there is no specific product to buy—only location/delivery/serviceability.
4) PLATFORM OVERVIEW: Broad questions like "welfog me kya kya milta", "kitne products", what Welfog sells in general -> intent="general", kb_keys include "company", "faqs". Not a product SKU search.
4b) COMPANY / TEAM / POLICY FROM KB: Questions about departments, staff, roles, "kya karta hai", office info, policies, FAQs -> intent="general". Choose kb_keys that match topic filenames when obvious; otherwise include several customer-facing keys (not only welfog_api). NEVER answer these as intent="product" unless they clearly ask to buy a physical SKU.
5) PRODUCT: Any specific shopping item question in ANY language or Roman Hindi/Hinglish: "show/buy/need", "dikhao/dikha", "milega/milta", "sakta/skta", "chahiye", "hai kya/h ky", "available", brand or product name alone -> intent="product".
   Set search_query to the core product/brand keyword in English (e.g. "cover h ky" -> "cover", "durex dikha" -> "durex", "pen mil sakta" -> "pen"). Strip question/filler words only.
   kb_keys include "welfog_api" and optionally "faqs".
6) FOLLOW-UPS: If the latest message uses pronouns (uska/uske/iska) or "yeh kya karta" without naming a product, use RECENT CONVERSATION to infer the subject. If it continues a non-shopping explanation (e.g. a department), intent="general" and search_query="".
7) ORDER/REFUND/PAYMENT: Existing-order tracking (track/status/where is my order) -> intent="order" with needs_order_id as appropriate; refund/payment similarly. kb_keys include respective policy file + "welfog_api" if needed.
8) OUT OF DOMAIN: unrelated chit-chat, homework, sports, politics, other companies -> is_welfog_related=false, intent="out_of_domain".
Return JSON only."""
        
        headers = {
            "Authorization": f"Bearer {groq_api_key}",
            "Content-Type": "application/json"
        }

        user_payload = user_msg
        if (conversation_context or "").strip():
            user_payload = (
                "RECENT CONVERSATION (use to resolve pronouns and follow-ups):\n"
                f"{conversation_context.strip()}\n\n"
                f"LATEST USER MESSAGE:\n{user_msg}"
            )

        payload = {
            "model": model_name,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_payload}
            ],
            "response_format": {"type": "json_object"}, 
            "temperature": 0.0
        }

        res = requests.post(url, headers=headers, json=payload, timeout=10)

        if res.status_code == 200:
            response_content = res.json()["choices"][0]["message"]["content"]
            
            # Print for debugging in your terminal to see how the AI is thinking!
            print("🧠 AI Reasoning:", json.loads(response_content).get("reasoning"))
            
            return json.loads(response_content)
        else:
            print(f"Groq API Error: {res.text}")
            return None
            
    except Exception as e:
        print("AI Brain Error:", e)
        return None


def ai_brain_answer(user_msg, kb_context, conversation_context: str = ""):
    """
    Step 2: Use Groq with selected KB context to generate final answer JSON.
    """
    try:
        groq_api_key = os.getenv("GROQ_API_KEY")
        if not groq_api_key:
            print("⚠️ ERROR: Groq API Key nahi mili! .env file check kar.")
            return None

        url = "https://api.groq.com/openai/v1/chat/completions"
        model_name = "llama-3.1-8b-instant"

        system_prompt = f"""You are 'Welfog AI', an intelligent e-commerce assistant for Welfog.
Analyze the user message semantically, use the KNOWLEDGE BASE as the source of truth, and return ONLY a valid JSON object.

WELFOG KNOWLEDGE BASE (Selected + relevant excerpts):
\"\"\"
{kb_context}
\"\"\"

JSON SCHEMA:
{{
  "reasoning": "Short reasoning (1-3 lines).",
  "intent": "product" | "order" | "refund" | "payment" | "seller" | "pincode_check" | "deals" | "categories" | "category_feed" | "general" | "out_of_domain",
  "search_query": "Clean product name if product intent, else empty",
  "extracted_pincode": "Extract the 6-digit PIN code if the user provides one, else empty string",
  "needs_order_id": true/false,
  "is_welfog_related": true/false,
  "response": "Final answer: complete enough to satisfy the question. If intent=categories or deals, guide user what you are showing."
}}

RULES:
- Follow the API PLAYBOOK instructions if present in KB (source=welfog_api).
- Do NOT invent products, prices, categories, or deals. If intent is "product", give a SHORT line that results are being shown — do NOT tell the user to only visit the website/app instead of searching.
- KNOWLEDGE ANSWERS: Read the excerpts fully. If the user asks for a list (e.g. department names, team list), output the actual names/details from the text — do NOT reply with only a document title, tag line, or \"According to...\" meta phrase. Use bullets or short sentences when listing multiple items.
- If the requested detail is not present in KB context, clearly say it is not available right now instead of guessing.
- Roman Hindi / Hinglish: specific item availability ("milega", "hai kya") -> intent "product" + search_query. Delivery-to-a-place / can-I-order-from-here / PIN-only messages -> intent "pincode_check" (ask for 6-digit PIN if missing). General "what is on Welfog" -> intent "general", not product.
- FOLLOW-UPS: If RECENT CONVERSATION is provided, resolve pronouns (uska/uske/iska/yeh) from the last turns; keep intent "general" when continuing an explanatory topic (e.g. what a department does) unless the user clearly switches to buying a product.
- Keep response clean and helpful; Hinglish/Hindi allowed based on user language."""

        headers = {
            "Authorization": f"Bearer {groq_api_key}",
            "Content-Type": "application/json"
        }

        user_payload = user_msg
        if (conversation_context or "").strip():
            user_payload = (
                "RECENT CONVERSATION:\n"
                f"{conversation_context.strip()}\n\n"
                f"LATEST USER MESSAGE:\n{user_msg}"
            )

        payload = {
            "model": model_name,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_payload}
            ],
            "response_format": {"type": "json_object"},
            "temperature": 0.0
        }

        res = requests.post(url, headers=headers, json=payload, timeout=12)
        if res.status_code == 200:
            response_content = res.json()["choices"][0]["message"]["content"]
            print("🧠 AI Reasoning:", json.loads(response_content).get("reasoning"))
            return json.loads(response_content)
        else:
            print(f"Groq API Error: {res.text}")
            return None
    except Exception as e:
        print("AI Brain Error:", e)
        return None
    
    # ================= MAIN ROUTE =================
@app.route("/")
def home():
    return render_template_string(HTML)


@app.route("/api/chat/new", methods=["POST"])
def new_chat_reset():
    user_id = request.remote_addr
    if user_id in user_contexts:
        reset_context(user_contexts[user_id])
    return jsonify({"status": "cleared"})

@app.route("/api/chats", methods=["GET"])
def get_history():
    user_id = request.remote_addr
    seven_days_ago = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d %H:%M:%S')
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT id, title, timestamp FROM chats WHERE user_id = ? AND timestamp >= ? ORDER BY id DESC", (user_id, seven_days_ago))
    chats = [{"id": r[0], "title": r[1], "date_str": r[2].split(" ")[0]} for r in cursor.fetchall()]
    conn.close()
    return jsonify(chats)

@app.route("/api/chat/messages/<int:chat_id>", methods=["GET"])
def get_messages(chat_id):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT sender, message FROM messages WHERE chat_id = ? ORDER BY id ASC", (chat_id,))
    msgs = [{"sender": r[0], "message": r[1]} for r in cursor.fetchall()]
    conn.close()
    return jsonify(msgs)


@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_msg = data.get("message", "").strip()
    user_id = request.remote_addr
    # Auto-sync KB on every request (handles add/update/delete .txt files dynamically)
    ensure_knowledge_cache_fresh()
    
    # 🔥 FIX 1: Frontend se chat_id fetch karo
    current_chat_id = data.get("chat_id")

    if user_id not in user_contexts:
        user_contexts[user_id] = {"intent": None, "awaiting": None, "data": {}, "last": None, "order_id": None}

    ctx = user_contexts[user_id]
    
    # 🔥 FIX 2: Agar Naya Chat hai (ID nahi hai), toh DB me create karo aur ID lo
    if not current_chat_id:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        title = user_msg[:30] + "..." if len(user_msg) > 30 else user_msg
        cursor.execute("INSERT INTO chats (user_id, title) VALUES (?, ?)", (user_id, title))
        current_chat_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
    # 🔥 FIX 3: User ka message database me save karo
    db_store_message(current_chat_id, "user", user_msg)

    original_msg = user_msg.strip()
    lang = detect_language(original_msg)
    
    msg_en = to_en(original_msg).lower().strip() if lang != "en" else original_msg.lower().strip()

    recent_msgs = db_get_recent_messages(current_chat_id, 12)
    conv_for_llm = _format_conversation_for_llm(recent_msgs)
    retrieval_query = build_retrieval_query(msg_en, conv_for_llm, original_msg)
    conv_sig = _conversation_cache_suffix(recent_msgs)

    intent = "general"
    search_query = ""
    is_welfog = True
    ai_response_text = ""
    ai_data = {}
    extracted_id = None

    # 🔥 FIX 4: Smart helper jo har reply ko (zarurat par) translate, save aur return karega.
    def send_reply(text_data, lang_code):
        """
        - Plain text replies -> user language me translate.
        - Structured HTML replies (product/deal cards etc.) -> as‑is, so CSS/markup multilingual me bhi break na ho.
        """
        if lang_code != "en" and isinstance(text_data, str) and any(tag in text_data for tag in ("<div", "<img", "<button", "<span", "<style")):
            # HTML content ko translate nahi karna, warna tags toot jate hain (non-English me layout bigadta hai)
            final_output = text_data
        else:
            final_output = to_user(text_data, lang_code)
        db_store_message(current_chat_id, "bot", final_output)
        return jsonify({"chat_id": current_chat_id, "type": "text", "data": final_output})


    # 1) STRICT STATE LOCKS (awaiting loops)
    if ctx.get("awaiting") == "order_id":
        if original_msg.lower() in ["cancel", "stop", "exit", "no"]:
            reset_context(ctx)
            return send_reply(sysmsg("cancelled"), lang)
            
        extracted_id = extract_order_id(msg_en)
        if extracted_id:
            intent = ctx.get("last") or "order"
            ctx["order_id"] = extracted_id
            ctx["awaiting"] = None
            ai_data = {"intent": intent, "is_welfog_related": True, "needs_order_id": True} 
        else:
            return send_reply(sysmsg("ask_order_id_generic"), lang)
    
    elif ctx.get("awaiting") == "category_select":
        if original_msg.lower() in ["cancel", "stop", "exit", "no"]:
            reset_context(ctx)
            return send_reply(sysmsg("cancelled"), lang)

        # If user asks a fresh/general question while awaiting category id,
        # unlock this state and continue with normal routing.
        if _looks_like_browse_all_categories_message(msg_en) or "department" in msg_en or "staff" in msg_en:
            ctx["awaiting"] = None

        # Try parse category id (e.g., "16", "id 16", "category 16")
        cat_id = get_category_id_from_text(msg_en, ctx=ctx)
        if not cat_id:
            m = re.search(r"\b(\d{1,5})\b", msg_en)
            if m:
                cat_id = m.group(1)

        color = _normalize_color(msg_en)
        if ctx.get("awaiting") == "category_select" and not cat_id:
            return send_reply(sysmsg("ask_category_select"), lang)

        intent = "product"
        search_query = ""  # category browse
        ai_data = {"intent": "product", "is_welfog_related": True, "search_query": ""}
        ctx["awaiting"] = None
        ctx["data"]["selected_category_id"] = cat_id
        ctx["data"]["selected_color"] = color

    # 2. NORMAL FLOW
    else:
        # If user directly says a category name ("electronics ke products dikhao"),
        # auto resolve category id and show products without asking for id.
        auto_cat_id = get_category_id_from_text(msg_en, ctx=ctx)
        if auto_cat_id and any(w in msg_en for w in ["category", "products", "product", "items", "dikhao", "show", "list"]):
            ctx.setdefault("data", {})
            ctx["data"]["selected_category_id"] = auto_cat_id
            ctx["data"]["selected_color"] = _normalize_color(msg_en)
            intent = "product"
            search_query = ""  # category browse
            ai_data = {"intent": "product", "is_welfog_related": True, "search_query": ""}

        # FAST GREETING CHECK (precomputed)
        if any(original_msg.lower() == g for g in GREETINGS) or cosine_similarity(model.encode([msg_en]), GREETINGS_VECS).max() > 0.75:
            reset_context(ctx)
            return send_reply(sysmsg("greeting"), lang)

        # ================= ⚡ 1. SMART INSTANT ROUTER (0.1s Execution) ⚡ =================
        fast_result = smart_instant_router(original_msg, msg_en)
        
        if fast_result:
            if fast_result["action"] == "reject" or fast_result["action"] == "text":
                reset_context(ctx)
                return send_reply(fast_result["data"], lang)
                
            elif fast_result["action"] == "product":
                reset_context(ctx)
                intent = "product"
                search_query = fast_result["query"]
                is_welfog = True
                
            elif fast_result["action"] == "ask_order_id":
                ctx["intent"] = fast_result["intent"]
                ctx["last"] = fast_result["intent"]
                ctx["awaiting"] = "order_id"
                return send_reply(sysmsg("ask_order_id_for_intent", intent=fast_result["intent"]), lang)
                
            elif fast_result["action"] == "direct_order_id":
                extracted_id = fast_result["order_id"]
                intent = ctx.get("last") or "order"
                ctx["order_id"] = extracted_id
                ctx["awaiting"] = None
                ai_data = {"intent": intent, "is_welfog_related": True, "needs_order_id": True}
                
        else:
            # ================= 🐢 2. AI BRAIN (Only for complex questions) 🐢 =================
            # kb_match = direct_kb_search(msg_en)
            # if kb_match:
            #     reset_context(ctx)
            #     return send_reply(kb_match, lang)
            
            if ctx.get("awaiting") == "order_id" and not extracted_id:
                reset_context(ctx)

            # PERF: short-term response cache (skip Groq entirely on repeats)
            resp_cache_key = f"resp::{current_chat_id}::{msg_en}::{conv_sig}"
            cached_ai = _cache_get(resp_cache_key)
            computed_fresh = False
            if cached_ai:
                ai_data = cached_ai
            else:
                computed_fresh = True
                # PERF: cheap local routing for common intents -> 1 Groq call instead of 2
                local_intent = None
                kb_keys = ["welfog_api"]
                txt = f" {msg_en} "
                comb = f"{original_msg} {msg_en}".lower()
                if any(w in txt for w in ["deal", "deals", "offer", "offers", "discount", "today deal"]):
                    local_intent = "deals"
                elif any(w in txt for w in ["category wise", "cat wise", "browse by category", "home page products", "category feed"]):
                    local_intent = "category_feed"
                elif any(w in txt for w in ["all categories", "categories list", "category list", "all category"]):
                    local_intent = "categories"
                elif _text_has_platform_overview_intent(comb):
                    local_intent = "general"
                    kb_keys = get_customer_kb_keys()
                elif _looks_like_conversational_followup(original_msg, msg_en) and len(recent_msgs) >= 2:
                    local_intent = "general"
                    kb_keys = get_customer_kb_keys()
                elif any(x in txt for x in ["staff", "department", "departments", "team", "teams"]):
                    local_intent = "general"
                    # For org/team questions, allow retrieval from all knowledge files.
                    kb_keys = get_customer_kb_keys()
                elif _text_has_delivery_or_order_area_intent(comb):
                    local_intent = "pincode_check"
                    kb_keys = ["shipping", "faqs", "company", "welfog_api"]
                elif _text_is_order_tracking_intent(comb):
                    local_intent = "order"
                    kb_keys += ["shipping", "faqs"]
                elif "refund" in txt or "return" in txt:
                    local_intent = "refund"
                    kb_keys += ["refund", "faqs"]
                elif any(w in txt for w in ["payment", "transaction", "upi"]):
                    local_intent = "payment"
                    kb_keys += ["payment", "faqs"]
                elif any(w in txt for w in ["seller", "become seller", "sell on welfog"]):
                    local_intent = "seller"
                    kb_keys += ["seller"]
                elif _text_has_product_shopping_intent(txt):
                    local_intent = "product"
                    kb_keys += ["faqs"]

                if local_intent:
                    # One-call answer with selected KB
                    kb_context = get_knowledge_context(
                        retrieval_query, keys=kb_keys, top_k=6, min_score=0.10
                    )
                    ai_data = ai_brain_answer(original_msg, kb_context, conv_for_llm) or {}
                    ai_data.setdefault("intent", local_intent)
                    ai_data.setdefault("is_welfog_related", True)
                else:
                    # Step 1: Route + choose knowledge files (Groq understands any language)
                    route_data = ai_brain_route(original_msg, conv_for_llm)
                    if not route_data:
                        fallback_text = sysmsg("server_busy")
                        return send_reply(fallback_text, lang)

                    kb_keys = route_data.get("kb_keys") or []
                    # Always include API playbook for shopping/deals/category flows
                    if route_data.get("intent") in ["product", "deals", "categories", "category_feed"] and "welfog_api" not in kb_keys:
                        kb_keys = list(kb_keys) + ["welfog_api"]
                    # For non-shopping informational intents, don't ground on internal playbook files.
                    if route_data.get("intent") in ["general", "seller", "refund", "payment"] and kb_keys:
                        kb_keys = [k for k in kb_keys if k not in INTERNAL_KB_KEYS] or get_customer_kb_keys()

                    # Step 2: Build KB context from selected files, then answer
                    kb_context = get_knowledge_context(
                        retrieval_query, keys=kb_keys, top_k=6, min_score=0.10
                    )
                    ai_data = ai_brain_answer(original_msg, kb_context, conv_for_llm)

                    if ai_data and "intent" not in ai_data:
                        # Safety: merge routing fields if model omitted them
                        ai_data["intent"] = route_data.get("intent", "general")
                        ai_data["is_welfog_related"] = route_data.get("is_welfog_related", True)

            # Note: ai_data already normalized above; avoid referencing route_data when local routing used.
            
            if not ai_data:
                fallback_text = sysmsg("server_busy")
                return send_reply(fallback_text, lang)

            apply_hinglish_product_fixes(original_msg, msg_en, ai_data)
            _merge_extracted_pincode(original_msg, msg_en, ai_data)
            if computed_fresh:
                _cache_set(resp_cache_key, ai_data)
            
            intent = ai_data.get("intent", "general")
            is_welfog = ai_data.get("is_welfog_related", True)
            search_query = ai_data.get("search_query") or msg_en 
            ai_response_text = ai_data.get("response", "")

            # If search text itself looks like a category (including typos), switch to category-wise product fetch.
            if intent == "product":
                typed_cat_id = get_category_id_from_text(search_query, ctx=ctx)
                if typed_cat_id:
                    ctx.setdefault("data", {})
                    ctx["data"]["selected_category_id"] = typed_cat_id
                    search_query = ""
                    ai_data["search_query"] = ""

            # Domain Control for AI responses
            if not is_welfog or intent == "out_of_domain":
                reset_context(ctx)
                fallback_msg = ai_response_text if ai_response_text else sysmsg("out_of_domain")
                return send_reply(fallback_msg, lang)
        
# ================= INTENT EXECUTION =================
    if intent == "product":
        # If user selected a category previously, use it automatically
        selected_cat = ctx.get("data", {}).get("selected_category_id")
        selected_color = ctx.get("data", {}).get("selected_color")
        # Also detect color from current query (overrides previous)
        detected_color = _normalize_color(msg_en)
        if detected_color:
            selected_color = detected_color

        products = fetch_products_from_api(search_query, category_id=selected_cat, color=selected_color, page=1)
        if products:
            title_q = search_query.strip()
            if selected_cat and not title_q:
                response_text = sysmsg("products_title_category")
            else:
                response_text = sysmsg("products_title_query", query=search_query)
            
            # 🔥 FIX: Container me 'flex-direction: row' lagaya aur width set ki taaki horizontal scroll bane
            response_text += "<div style='display: flex; flex-direction: row; overflow-x: auto; gap: 12px; padding: 5px 5px 15px 5px; width: 100%; max-width: 260px; scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch;'>"
            
            for p in products:
                # Individual Card
                response_text += "<div style='flex: 0 0 auto; width: 160px; border: 1px solid #e0e0e0; border-radius: 10px; padding: 12px; background: #fff; box-shadow: 0 3px 6px rgba(0,0,0,0.08); display: flex; flex-direction: column; scroll-snap-align: start; transition: transform 0.2s;'>"
                
                if p['image']:
                    response_text += f"<div style='width: 100%; height: 130px; background-color: #f9f9f9; border-radius: 8px; overflow: hidden; margin-bottom: 10px; display: flex; align-items: center; justify-content: center; border: 1px solid #f0f0f0;'><img src='{p['image']}' alt='{p['name']}' style='max-width: 100%; max-height: 100%; object-fit: contain; display: block;'></div>"
                else:
                    response_text += f"<div style='width: 100%; height: 130px; background: #f0f0f0; border-radius: 8px; margin-bottom: 10px; display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px; border: 1px solid #e0e0e0;'>{sysmsg('no_image')}</div>"
                
                name_short = p['name'][:38] + '...' if len(p['name']) > 38 else p['name']
                response_text += f"<div style='font-size: 13px; font-weight: 600; color: #333; margin-bottom: 6px; height: 34px; overflow: hidden; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;'>{name_short}</div>"
                response_text += f"<div style='font-size: 15px; font-weight: bold; color: #ff7a00; margin-bottom: 12px; margin-top: auto;'>₹{p['price']}</div>"
                
                if p['link']:
                    response_text += f"<a href='{p['link']}' target='_blank' style='display: block; text-align: center; background-color: #ff7a00; color: white; padding: 7px 0; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: bold; transition: background 0.2s;'>{sysmsg('view_product')}</a>"
                
                # 🔥 FIX: Yahan sirf Card wala div close hoga
                response_text += "</div>" 
            
            # 🔥 FIX: Loop khatam hone ke baad Horizontal Scroll wala div close hoga
            response_text += "</div>"
        else:
            if selected_cat and not (search_query or "").strip():
                response_text = sysmsg("category_products_not_found")
            else:
                response_text = sysmsg("product_not_found", query=search_query)
        reset_context(ctx)
    elif intent == "categories":
        cats = fetch_nav_categories()
        if not cats:
            response_text = sysmsg("categories_unavailable")
        else:
            # Try to extract a reasonable list from various possible shapes
            items = []
            if isinstance(cats, dict):
                for key in ["data", "categories", "result"]:
                    if isinstance(cats.get(key), list):
                        items = cats.get(key)
                        break
            elif isinstance(cats, list):
                items = cats

            # Flatten first-level items only
            shown = []
            for it in items[:20]:
                if not isinstance(it, dict):
                    continue
                cid = it.get("id") or it.get("category_id") or it.get("cat_id")
                name = it.get("name") or it.get("title") or it.get("category_name")
                if cid and name:
                    shown.append((cid, name))

            if not shown:
                response_text = sysmsg("categories_parse_failed")
            else:
                # Store categories map for next message selection
                ctx.setdefault("data", {})
                ctx["data"]["categories_map"] = {str(name).lower(): str(cid) for cid, name in shown}
                response_text = sysmsg("categories_title")
                response_text += sysmsg("categories_list_wrap_start")
                for cid, name in shown:
                    response_text += f"• <b>{name}</b> (id: {cid})<br>"
                response_text += sysmsg("categories_list_wrap_end") + sysmsg("categories_footer")
        # Keep context so next user message can select a category
        ctx["awaiting"] = "category_select"
    elif intent == "deals":
        deals = fetch_today_deals()
        items = []
        if isinstance(deals, dict):
            for key in ["data", "products", "result", "today_deal"]:
                if isinstance(deals.get(key), list):
                    items = deals.get(key)
                    break
        elif isinstance(deals, list):
            items = deals

        if not items:
            response_text = sysmsg("deals_unavailable")
        else:
            IMAGE_BASE_URL = "https://d1f02fefkbso7w.cloudfront.net/"
            response_text = sysmsg("deals_title", title=(deals.get("title") if isinstance(deals, dict) else None) or sysmsg("default_deals_name"))
            response_text += "<div style='display: flex; flex-direction: row; overflow-x: auto; gap: 12px; padding: 5px 5px 15px 5px; width: 100%; max-width: 260px; scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch;'>"

            shown = 0
            for p in items:
                if shown >= 5:
                    break
                if not isinstance(p, dict):
                    continue
                name = p.get("name") or p.get("product_name") or sysmsg("default_deal_card_title")
                new_price = p.get("new_price") or p.get("main_price") or p.get("price") or p.get("base_price") or sysmsg("na_price")
                old_price = p.get("old_price")
                slug = p.get("slug") or ""
                thumb = p.get("thumbnail_img") or p.get("thumbnail_image") or p.get("image") or ""
                image = (IMAGE_BASE_URL + str(thumb).lstrip("/")) if thumb else ""
                link = f"https://welfog.com/product/{slug}" if slug else "https://welfog.com"

                response_text += "<div style='flex: 0 0 auto; width: 160px; border: 1px solid #e0e0e0; border-radius: 10px; padding: 12px; background: #fff; box-shadow: 0 3px 6px rgba(0,0,0,0.08); display: flex; flex-direction: column; scroll-snap-align: start;'>"
                if image:
                    response_text += f"<div style='width: 100%; height: 130px; background-color: #f9f9f9; border-radius: 8px; overflow: hidden; margin-bottom: 10px; display: flex; align-items: center; justify-content: center; border: 1px solid #f0f0f0;'><img src='{image}' alt='{name}' style='max-width: 100%; max-height: 100%; object-fit: contain; display: block;'></div>"
                else:
                    response_text += f"<div style='width: 100%; height: 130px; background: #f0f0f0; border-radius: 8px; margin-bottom: 10px; display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px; border: 1px solid #e0e0e0;'>{sysmsg('no_image')}</div>"

                name_short = name[:38] + "..." if len(name) > 38 else name
                response_text += f"<div style='font-size: 13px; font-weight: 600; color: #333; margin-bottom: 6px; height: 34px; overflow: hidden; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;'>{name_short}</div>"
                if old_price and str(old_price).strip() and str(old_price) != str(new_price):
                    response_text += "<div style='margin-bottom: 10px; margin-top: auto;'>"
                    response_text += f"<span style='font-size: 15px; font-weight: bold; color: #ff7a00;'>₹{new_price}</span> "
                    response_text += f"<span style='font-size: 12px; color: #888; text-decoration: line-through;'>₹{old_price}</span>"
                    response_text += "</div>"
                else:
                    response_text += f"<div style='font-size: 15px; font-weight: bold; color: #ff7a00; margin-bottom: 12px; margin-top: auto;'>₹{new_price}</div>"
                response_text += f"<a href='{link}' target='_blank' style='display: block; text-align: center; background-color: #ff7a00; color: white; padding: 7px 0; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: bold;'>{sysmsg('view_deal')}</a>"
                response_text += "</div>"
                shown += 1

            response_text += "</div>"
        reset_context(ctx)
    elif intent == "category_feed":
        feed = fetch_category_wise_feed(page=1)
        groups = []
        if isinstance(feed, dict) and isinstance(feed.get("data"), list):
            groups = feed.get("data")

        if not groups:
            response_text = sysmsg("cat_feed_unavailable")
        else:
            IMAGE_BASE_URL = "https://d1f02fefkbso7w.cloudfront.net/"
            response_text = sysmsg("category_feed_title")
            shown_groups = 0
            for g in groups:
                if shown_groups >= 2:
                    break
                if not isinstance(g, dict):
                    continue
                cat = g.get("category") or {}
                cat_name = cat.get("name") or sysmsg("default_category_title")
                prods = g.get("products") if isinstance(g.get("products"), list) else []
                if not prods:
                    continue

                response_text += f"<div style='margin: 10px 0 6px 0; color:#333; font-weight:700;'>{cat_name}</div>"
                response_text += "<div style='display: flex; flex-direction: row; overflow-x: auto; gap: 12px; padding: 5px 5px 15px 5px; width: 100%; max-width: 260px; scroll-snap-type: x mandatory; -webkit-overflow-scrolling: touch;'>"
                shown = 0
                for p in prods:
                    if shown >= 5:
                        break
                    if not isinstance(p, dict):
                        continue
                    name = p.get("name") or sysmsg("default_product_card_title")
                    price = p.get("price") or sysmsg("na_price")
                    link_slug = p.get("link") or p.get("slug") or ""
                    thumb = p.get("image") or p.get("thumbnail_img") or p.get("thumbnail_image") or ""
                    image = (IMAGE_BASE_URL + str(thumb).lstrip("/")) if thumb else ""
                    link = f"https://welfog.com/product/{link_slug}" if link_slug else "https://welfog.com"

                    response_text += "<div style='flex: 0 0 auto; width: 160px; border: 1px solid #e0e0e0; border-radius: 10px; padding: 12px; background: #fff; box-shadow: 0 3px 6px rgba(0,0,0,0.08); display: flex; flex-direction: column; scroll-snap-align: start;'>"
                    if image:
                        response_text += f"<div style='width: 100%; height: 130px; background-color: #f9f9f9; border-radius: 8px; overflow: hidden; margin-bottom: 10px; display: flex; align-items: center; justify-content: center; border: 1px solid #f0f0f0;'><img src='{image}' alt='{name}' style='max-width: 100%; max-height: 100%; object-fit: contain; display: block;'></div>"
                    else:
                        response_text += f"<div style='width: 100%; height: 130px; background: #f0f0f0; border-radius: 8px; margin-bottom: 10px; display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px; border: 1px solid #e0e0e0;'>{sysmsg('no_image')}</div>"
                    name_short = name[:38] + "..." if len(name) > 38 else name
                    response_text += f"<div style='font-size: 13px; font-weight: 600; color: #333; margin-bottom: 6px; height: 34px; overflow: hidden; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;'>{name_short}</div>"
                    response_text += f"<div style='font-size: 15px; font-weight: bold; color: #ff7a00; margin-bottom: 12px; margin-top: auto;'>₹{price}</div>"
                    response_text += f"<a href='{link}' target='_blank' style='display: block; text-align: center; background-color: #ff7a00; color: white; padding: 7px 0; text-decoration: none; border-radius: 6px; font-size: 12px; font-weight: bold;'>{sysmsg('view_product')}</a>"
                    response_text += "</div>"
                    shown += 1

                response_text += "</div>"
                shown_groups += 1
        reset_context(ctx)
    elif intent == "pincode_check":
        pincode = ai_data.get("extracted_pincode", "")
        
        if not pincode:
            response_text = sysmsg("ask_pincode")
        else:
            api_res = check_pincode_delivery(pincode)
            
            # 🔥 Super Smart Response Logic
            if api_res and api_res.get("result") is True:
                message = api_res.get("message", "Product is available!")
                distance = api_res.get("distance", "nearby")
                
                response_text = (
                    f"✅ <b>Good News!</b><br>"
                    f"{message}<br><br>"
                    f"📍 Pincode: <b>{pincode}</b><br>"
                    f"🚚 Distance: <b>{distance}</b><br><br>"
                    f"you can place your order!"
                )
            elif api_res and api_res.get("result") is False:
                response_text = f"❌ sorry, PIN code <b>{pincode}</b> here we are not available to deliver , you can try another location ."
            else:
                # Agar API fail ho jaye ya response na mile
                response_text = sysmsg("server_technical_issue")
        
        reset_context(ctx)

    elif intent in ["order", "refund", "payment"]:
        ctx["last"] = intent
        needs_id = ai_data.get("needs_order_id", True) 
        current_order_id = ctx.get("order_id")

        # 🔥 MAJOR BUG FIX: Agar needs_id True hai (Tracking), tabhi ID maango.
        if needs_id:
            if not current_order_id:
                ctx["awaiting"] = "order_id"
                response_text = sysmsg("ask_order_id_for_intent", intent=intent)
            else:
                if intent == "order":
                    res = fetch_api("order", current_order_id)
                    response_text = f"Order {current_order_id} is {res['status']} and will arrive in {res['delivery']}." if res else "Order not found."
                elif intent == "refund":
                    res = fetch_api("refund", current_order_id)
                    response_text = f"Refund status: {res['status']}. Expected in {res['time']}." if res else "No refund record found."
                elif intent == "payment":
                    res = fetch_api("payment", current_order_id)
                    response_text = f"Payment status: {res['status']} via {res['method']}." if res else "Payment details not found."
                reset_context(ctx)
        else:
            # 🔥 MAJOR BUG FIX: Agar needs_id False hai, iska matlab wo FAQ hai. AI ka direct answer dikhao!
            response_text = ai_response_text if ai_response_text else sysmsg("how_can_i_help")
            reset_context(ctx)

    else:
        if ai_response_text:
            response_text = ai_response_text
        else:
            grounded = direct_kb_search(retrieval_query, keys=get_customer_kb_keys(), min_score=0.38)
            response_text = grounded if grounded else sysmsg("how_can_i_help_welfog")
        reset_context(ctx)

    # ================= FINAL RESPONSE =================
    return send_reply(response_text, lang)


# if __name__ == '__main__':
#     app.run(port=5000, debug=True)

# ================= UI =================
HTML = """
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
body {
    margin:0;
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg,#000000,#1a1a1a,#000000); 
    display: flex; justify-content: center; align-items: center; height: 100vh;
}

.container {
    width: 400px; height: 90vh;
    background: #0f0f0f; 
    border-radius: 12px;
    display: flex; flex-direction: column;
    box-shadow: 0 0 25px rgba(255,140,0,0.3);
    position: relative; /* Fixed for Sidebar */
    overflow: hidden;   /* Fixed for Sidebar */
}

/* --- NEW: History Sidebar --- */
.history-panel {
    position: absolute; top: 0; left: -250px; 
    width: 250px; height: 100%;
    background: #111; z-index: 10; transition: left 0.3s ease;
    display: flex; flex-direction: column;
    border-right: 1px solid #333;
}
.history-panel.open { left: 0; }
.history-header {
    padding: 15px; background: #222; color: #ff7a00;
    font-weight: bold; display: flex; justify-content: space-between; align-items: center;
}
.history-list { flex: 1; overflow-y: auto; padding: 10px; }
.hist-item { 
    padding: 10px; background: #1a1a1a; color: #ccc; 
    margin-bottom: 8px; border-radius: 6px; cursor: pointer; font-size: 13px;
    border-left: 3px solid transparent; transition: 0.2s;
}
.hist-item:hover { background: #2a2a2a; border-left: 3px solid #ff7a00; color: #fff; }
.hist-title { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.hist-date { font-size: 10px; color: #777; margin-top: 4px; }

/* Header with Icons */
.header {
    padding: 15px; background: #ff7a00; color: white;
    font-size: 18px; font-weight: bold; 
    display: flex; justify-content: space-between; align-items: center;
}
.icon-btn { background: none; border: none; color: white; font-size: 18px; cursor: pointer; }

.chat { flex: 1; overflow-y: auto; padding: 10px; scroll-behavior: smooth; }
.msg { 
    max-width: 75%; 
    padding: 10px; 
    margin: 6px; 
    border-radius: 10px; 
    animation: fadeIn 0.3s ease; 
    display: flex; 
    flex-direction: column;
    /* Multilingual + long text safety */
    overflow-wrap: anywhere;
    word-break: break-word;
}
.user { background: #ff7a00; color: white; align-self: flex-end; }
.bot { 
    background: #ffffff; 
    color: #000; 
    align-self: flex-start; 
    box-shadow: 0 0 8px rgba(255,255,255,0.2);
    /* Bot messages often contain cards/images */
    max-width: 90%;
    overflow: hidden;
}

/* Ensure any injected HTML cannot overflow the bubble */
.msg, .msg * { box-sizing: border-box; max-width: 100%; }
.msg img, .msg svg, .msg video, .msg iframe { max-width: 100% !important; height: auto !important; }
.msg pre, .msg code { white-space: pre-wrap; overflow-wrap: anywhere; }

.inputBox { display: flex; padding: 10px; background: #000000; }
input { flex:1; padding:10px; border:none; border-radius:6px; background: #ffffff; color: #000; }
button.send-btn { margin-left:10px; padding:10px 15px; border:none; background:#ff7a00; color:white; border-radius:6px; cursor:pointer; transition: 0.3s; }
button.send-btn:hover { background:#ff9a33; }

.typing { font-size: 14px; margin: 5px; padding: 8px; background: #ffffff; color: #000; border-radius: 8px; display: inline-block; align-self: flex-start;}
.dot { animation: blink 1.4s infinite; }
.dot:nth-child(2) { animation-delay: .2s; }
.dot:nth-child(3) { animation-delay: .4s; }

@keyframes blink { 0% { opacity: 0; } 50% { opacity: 1; } 100% { opacity: 0; } }
@keyframes fadeIn { from { opacity:0; transform:translateY(10px);} to { opacity:1; transform:translateY(0);} }
</style>
</head>

<body>

<div class="container">
    <div class="history-panel" id="historyPanel">
        <div class="history-header">
            <span>Past 7 Days</span>
            <button class="icon-btn" onclick="toggleHistory()"><i class="fas fa-times"></i></button>
        </div>
        <div class="history-list" id="historyList"></div>
    </div>

    <div class="header">
        <button class="icon-btn" onclick="toggleHistory()"><i class="fas fa-bars"></i></button>
        <span>🤖 Welfog AI</span>
        <button class="icon-btn" onclick="newChat()" title="New Chat"><i class="fas fa-plus"></i></button>
    </div>

    <div id="chat" class="chat">
        <div class="msg bot">Hello! How can I help you with Welfog today? 😊</div>
    </div>

    <div class="inputBox">
        <input id="msg" placeholder="Type your message..." onkeypress="if(event.key === 'Enter') send()" />
        <button class="send-btn" onclick="send()"><i class="fas fa-paper-plane"></i></button>
    </div>
</div>

<script>
const chat = document.getElementById("chat");
let currentChatId = null; // Track current session

function addMessage(text, type){
    let div = document.createElement("div");
    div.className = "msg " + type;
    div.innerHTML = text; 
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
}

function showTyping(){
    let div = document.createElement("div");
    div.className = "typing";
    div.id = "typing";
    div.innerHTML = "Typing<span class='dot'>.</span><span class='dot'>.</span><span class='dot'>.</span>";
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
}

function removeTyping(){
    let t = document.getElementById("typing");
    if(t) t.remove();
}

// ================= NEW FEATURES LOGIC =================

// 1. Send Message (Updated with chat_id)
async function send(){
    let input = document.getElementById("msg");
    let message = input.value.trim();
    if(!message) return;

    addMessage(message, "user");
    input.value = "";
    showTyping();

    try{
        let res = await fetch("/chat",{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body: JSON.stringify({message: message, chat_id: currentChatId}) // 🔥 Pass ID
        });
        let data = await res.json();
        
        if(data.chat_id) currentChatId = data.chat_id; // 🔥 Save new ID

        removeTyping();
        addMessage(data.data, "bot");
    }catch(e){
        removeTyping();
        addMessage("Server error...", "bot");
    }
}

// 2. New Chat
async function newChat() {
    chat.innerHTML = "";
    currentChatId = null;
    await fetch("/api/chat/new", {method: "POST"}); // Backend reset
    addMessage("Started a new chat! How can I help you?", "bot");
    document.getElementById("historyPanel").classList.remove("open");
}

// 3. Toggle & Load History
async function toggleHistory() {
    let panel = document.getElementById("historyPanel");
    panel.classList.toggle("open");
    
    if(panel.classList.contains("open")) {
        let list = document.getElementById("historyList");
        list.innerHTML = "<div style='color:#888;text-align:center;'>Loading...</div>";
        
        let res = await fetch("/api/chats");
        let chats = await res.json();
        
        list.innerHTML = "";
        if(chats.length === 0) list.innerHTML = "<div style='color:#555;text-align:center;margin-top:20px;'>No recent chats</div>";
        
        chats.forEach(c => {
            let div = document.createElement("div");
            div.className = "hist-item";
            div.innerHTML = `<div class="hist-title">${c.title}</div><div class="hist-date">${c.date_str}</div>`;
            div.onclick = () => loadOldChat(c.id);
            list.appendChild(div);
        });
    }
}

// 4. Load Old Chat Messages
async function loadOldChat(id) {
    chat.innerHTML = "";
    currentChatId = id;
    document.getElementById("historyPanel").classList.remove("open");
    
    let res = await fetch(`/api/chat/messages/${id}`);
    let msgs = await res.json();
    
    msgs.forEach(m => {
        addMessage(m.message, m.sender === "user" ? "user" : "bot");
    });
    chat.scrollTop = chat.scrollHeight;
}
</script>
</body>
</html>
"""

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(port=5000, debug=True)


# if __name__ == "__main__":
#     app.run(debug=True)

